package FoodFinder.fragments;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.deepu.foodfinder.R;
import com.firebase.client.Firebase;

/**
 * Created by deepu on 11/05/16.
 */
public class MainFragment extends Fragment  {



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {



        View rootView =  inflater.inflate(R.layout.content_main,container,false);
        return rootView;

    }
}
