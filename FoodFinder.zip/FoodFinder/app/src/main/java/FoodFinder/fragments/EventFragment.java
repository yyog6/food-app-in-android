package FoodFinder.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.deepu.foodfinder.R;
import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link EventFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link EventFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EventFragment extends Fragment {
    EditText EName,PName,ETDate,ECmmnt;
    Button BCreate;
    Button BClear;
    Firebase ref,newref;
    AuthData authData;
    ProgressDialog PD;

    //https://github.com/marceand/MChat/commits/master reference
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_event, container, false);


        Firebase.setAndroidContext(getContext());
        ref = new Firebase("https://login-foodie-finder.firebaseio.com/");
        newref = ref.push();
        authData = ref.getAuth();

        PD = new ProgressDialog(getContext());
        PD.setMessage("Loading...");
        //final Bundle bundle=getArguments();



        EName = (EditText) rootView.findViewById(R.id.evnt_name);
        PName = (EditText) rootView.findViewById(R.id.e_name);
        ETDate = (EditText) rootView.findViewById(R.id.eTime);
        ECmmnt = (EditText) rootView.findViewById(R.id.eComment);
        BCreate = (Button) rootView.findViewById(R.id.btn_create);
        BClear = (Button) rootView.findViewById(R.id.btn_clear);



        BCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PD.show();
                String evName = EName.getText().toString();
                String evPname = PName.getText().toString();
                String evTime = ETDate.getText().toString();
                String evCommnt = ECmmnt.getText().toString();



                ref.child("users").child(evName).child("evname").setValue(evName, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                        if (firebaseError != null) {
                            Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_SHORT).show();
                        }
                        PD.dismiss();
                    }
                });

                ref.child("users").child(evPname).child("evPname").setValue(evPname, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                        if (firebaseError != null) {
                            Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_SHORT).show();
                        }
                        PD.dismiss();
                    }
                });

                ref.child("users").child(evTime).child("evTime").setValue(evTime, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                        if (firebaseError != null) {
                            Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_SHORT).show();
                        }
                        PD.dismiss();
                    }
                });
                ref.child("users").child(evCommnt).child("evCommnt").setValue(evCommnt, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                        if (firebaseError != null) {
                            Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_SHORT).show();
                        }
                        PD.dismiss();
                    }

                });
            }
        });

        BClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PD.show();
                EName.setText("");
                PName.setText("");
                ETDate.setText("");
                ECmmnt.setText("");
                PD.dismiss();
            }


        });




        return rootView;
    }
}
