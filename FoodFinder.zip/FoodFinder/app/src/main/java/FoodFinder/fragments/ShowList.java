package FoodFinder.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.deepu.foodfinder.R;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ShowList.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ShowList#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ShowList extends Fragment {
    TextView le_name,lp_name,lt_time,lu_cmmnts;
    EditText new_cmmnts;
    Button save_cmmnts;
    Firebase ref;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.fragment_show_list,container,false);

        Firebase.setAndroidContext(getContext());
        ref=new Firebase("https://login-foodie-finder.firebaseio.com/");


        le_name=(TextView)rootView.findViewById(R.id.list_name);
        lp_name=(TextView)rootView.findViewById(R.id.l_name);
        lt_time=(TextView)rootView.findViewById(R.id.lTime);
        lu_cmmnts=(TextView)rootView.findViewById(R.id.lComment);
        new_cmmnts=(EditText)rootView.findViewById(R.id.list_cmmnt);
        save_cmmnts=(Button)rootView.findViewById(R.id.save_cmmnt);

     ref.addValueEventListener(new ValueEventListener() {
         @Override
         public void onDataChange(DataSnapshot dataSnapshot) {


             le_name.setText((CharSequence) dataSnapshot.child("users").child("evname").getValue());
             lp_name = (TextView) dataSnapshot.child("users"). child("evPname").getValue();
             lt_time = (TextView) dataSnapshot.child("users").child("evTime").getValue();
             lu_cmmnts = (TextView) dataSnapshot.child("users").child("evCmmnt").getValue();
         }

         @Override
         public void onCancelled(FirebaseError firebaseError) {

         }
     });




      //  String lname=le_name.getText().toString();





        return rootView;

        

    }
}


