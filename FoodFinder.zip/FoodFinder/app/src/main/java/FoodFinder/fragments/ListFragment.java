package FoodFinder.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.deepu.foodfinder.R;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import Model.RModel;

import static java.security.AccessController.getContext;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the  factory method to
 * create an instance of this fragment.
 */
public class ListFragment extends Fragment {
    @Nullable
    private ListView lvRest;
    // private RecyclerView recyclerView;
    private TextView tvData;
    private ImageView imView;
    private ListView lvRest1;
    //  private ListAdapter adapter;

    private List<RModel> rModelList = new ArrayList<>();
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        new JsonTask().execute("https://api.zomato.com/v2/search.json?city_id=259&cc=1&count=100&apikey=4f4b91f51207b8175170604f4b91f512");


        // Create default options which will be used for every
//  displayImage(...) call if no options will be passed to this method
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .build();
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getContext())
                .defaultDisplayImageOptions(defaultOptions)
                .build();
        ImageLoader.getInstance().init(config); // Do it on Application start



        lvRest1 = (ListView)rootView.findViewById(R.id.lvRest);

        return rootView;
    }

    public class JsonTask extends AsyncTask<String, String, List<RModel> > {

        String temp = null;

        @Override
        protected List<RModel> doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;


            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();

                String line = "";
                while ((line = reader.readLine()) != null) {

                    buffer.append(line);

                }
                temp = buffer.toString();


                JSONObject parentObject = new JSONObject(temp);
                JSONArray parentArray = parentObject.getJSONArray("restaurants");


                Gson gson = new Gson();
                for (int i = 0; i < parentArray.length(); i++) {
                    JSONObject finalObject = parentArray.getJSONObject(i).getJSONObject("restaurant");



                    RModel rModel = new RModel();
                    String name = finalObject.getString("name");
                    rModel.setName(finalObject.getString("name"));
                    rModel.setImage(finalObject.getString("obp_url"));
                    rModel.setUrl(finalObject.getString("url"));
                    List<RModel.location> locationList = new ArrayList<>();
                        JSONObject locationObject = finalObject.getJSONObject("location");
                        RModel.location Location = new RModel.location();
                        Location.setAddress(locationObject.getString("address"));
                        Location.setCity(locationObject.getString("city"));
                        Location.setLocality(locationObject.getString("locality"));
                        locationList.add(Location);
                    rModel.setLocationList(locationList);
                    List<RModel.user_rating> userRatingList = new ArrayList<>();

                        RModel.user_rating userRating= new RModel.user_rating();
                        userRating.setAggregate_rating(finalObject.getJSONObject("user_rating").getString("aggregate_rating"));
                        userRatingList.add(userRating);
                    rModel.setRatingList(userRatingList);
                        rModelList.add(rModel);
                    }

                    return rModelList;

            }catch (IOException e) {
                e.printStackTrace();
            } finally {

                if (connection != null) connection.disconnect();
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        }

        @Override
        protected void onPostExecute(final List<RModel> result) {
            super.onPostExecute(result);
            RestAdapter adapter = new RestAdapter(getContext() ,R.layout.row, rModelList );
            lvRest1.setAdapter(adapter);
        }




}
}

class RestAdapter extends ArrayAdapter
{
    private List<RModel> RModelList;
    private int Resource;
    private LayoutInflater inflater;
    public RestAdapter(Context context, int resource, List<RModel> objects) {
        super(context, resource, objects);
        RModelList = objects;
        this.Resource = resource;
        inflater= (LayoutInflater) getContext().getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        View row = convertView;
        if(convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
            holder = new ViewHolder();
            convertView.setTag(holder);

            holder.ivIcon = (ImageView) convertView.findViewById(R.id.ivIcon);
            holder.rName = (TextView) convertView.findViewById(R.id.rName);
            holder.urlId = (TextView) convertView.findViewById(R.id.urlId);
            holder.addressId = (TextView) convertView.findViewById(R.id.addressId);
            holder.cityId = (TextView) convertView.findViewById(R.id.cityId);
            holder.rating = (TextView) convertView.findViewById(R.id.rating);
            holder.localityId = (TextView) convertView.findViewById(R.id.localityId);


            holder.rName.setText(RModelList.get(position).getName());
            holder.urlId.setText(RModelList.get(position).getUrl());

            StringBuffer stringBuffer = new StringBuffer();
            RModel.location location = RModelList.get(position).getLocationList().get(0);
            holder.addressId.setText(location.getAddress());
            holder.cityId.setText(location.getCity());
            holder.localityId.setText(location.getLocality());


            holder.rating.setText(RModelList.get(position).getRatingList().get(0).getAggregate_rating());
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

        final ProgressBar progressBar = (ProgressBar)convertView.findViewById(R.id.progressBar);


        ImageLoader.getInstance().displayImage(RModelList.get(position).getImage(), holder.ivIcon, new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                progressBar.setVisibility(View.GONE);

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                progressBar.setVisibility(View.GONE);

            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {
                progressBar.setVisibility(View.GONE);

            }
        });
        holder.rName.setText(RModelList.get(position).getName());
        holder.urlId.setText(RModelList.get(position).getUrl());


        return convertView;
    }
  class ViewHolder{


     private ImageView ivIcon;
     private TextView rName;
     private TextView urlId;
     private TextView addressId;
     private TextView localityId;
      private TextView cityId;
     private TextView rating;


  }


}



