package FoodFinder.fragments;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.deepu.foodfinder.R;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;


//https://codeload.github.com/firebase/firebase-simple-login-java/zip/master firebase refernce


public class LoginFragment extends Fragment {


    EditText edt_name,edt_pass;
    Button btn_signin,btn_passwd;
    Firebase ref;
    ProgressDialog PD;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.fragment_login,container,false);


        Firebase.setAndroidContext(getContext());
        ref = new Firebase("https://login-foodie-finder.firebaseio.com/");

        PD = new ProgressDialog(getContext());
        PD.setMessage("Loading...");

        edt_name = (EditText)rootView.findViewById(R.id.edt_name);
        edt_pass = (EditText)rootView.findViewById(R.id.edt_pass);
        btn_signin = (Button)rootView.findViewById(R.id.btn_link1);
        btn_passwd=(Button)rootView.findViewById(R.id.btn_pass);

        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PD.show();
                final String name = edt_name.getText().toString();
                final String pass = edt_pass.getText().toString();

                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if (name.equals(dataSnapshot.child("users").child(name).child("name").getValue())
                                &&pass.equals(dataSnapshot.child("users").child(name).child("pass").getValue())) {
                            Toast.makeText(getContext(), "Success", Toast.LENGTH_SHORT).show();
                            EventFragment ev=new EventFragment();
                            FragmentManager nfm1=getFragmentManager();
                            FragmentTransaction ft4= nfm1.beginTransaction();
                            Bundle args=new Bundle();
                            args.putString("name",name);
                            ev.setArguments(args);
                            ft4.commit();

                            ListFragment lt1 = new ListFragment();
                            FragmentManager fm2 = getFragmentManager();
                            FragmentTransaction ft2 = fm2.beginTransaction();
                            ft2.replace(R.id.content_frame,lt1);
                            ft2.commit();
                        } else {
                            Toast.makeText(getContext(), "Incorrect Credentials", Toast.LENGTH_SHORT).show();
                        }
                        PD.dismiss();
                    }


                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            }
        });


        btn_passwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Forgot forgot = new Forgot();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.content_frame,forgot);
                ft.commit();
            }
        });

      //  Intent intent = new Intent("MainActivity.class");
       // startActivity(intent);

        return rootView;




    }


}
