package FoodFinder.fragments;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.example.deepu.foodfinder.R;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

/**
 * Created by deepu on 11/05/16.
 */

//https://www.youtube.com/watch?v=z6pTJ-qryKA (Refernce)
    //https://www.youtube.com/watch?v=B1rlT5KQ0yE (refernce)
public class RegisterFragment extends Fragment {


    EditText edt_name,edt_mail,edt_pass;
    Button btn_signup,btn_signin;
    Firebase ref;
    ProgressDialog PD;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.fragment_register,container,false);

        Firebase.setAndroidContext(getContext());
        ref = new Firebase("https://login-foodie-finder.firebaseio.com/");


        PD = new ProgressDialog(getContext());
        PD.setMessage("Loading...");

        edt_name = (EditText)rootView.findViewById(R.id.edt_name);
        edt_mail = (EditText)rootView.findViewById(R.id.edt_mail);
        edt_pass = (EditText)rootView.findViewById(R.id.edt_pass);
        btn_signin = (Button)rootView.findViewById(R.id.btn_link);
        btn_signup = (Button)rootView.findViewById(R.id.btn_reg);




        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PD.show();
                String name = edt_name.getText().toString();
                String email = edt_mail.getText().toString();
                String pass = edt_pass.getText().toString();


                    ref.child("users").child(name).child("name").setValue(name, new Firebase.CompletionListener() {

                        @Override
                        public void onComplete(FirebaseError error, Firebase firebase) {
                            if (error != null) {
                                Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_LONG).show();
                            }
                            PD.dismiss();
                        }
                    });

                    ref.child("users").child(name).child("email").setValue(email, new Firebase.CompletionListener() {
                        @Override
                        public void onComplete(FirebaseError error, Firebase firebase) {
                            if (error != null) {
                                Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_LONG).show();
                            }
                            PD.dismiss();
                        }
                    });

                    ref.child("users").child(name).child("pass").setValue(pass, new Firebase.CompletionListener() {
                        @Override
                        public void onComplete(FirebaseError error, Firebase firebase) {
                            if (error != null) {
                                Toast.makeText(getContext(), "Retry Again", Toast.LENGTH_LONG).show();
                            }
                            PD.dismiss();
                        }
                    });

                    ListFragment lt1 = new ListFragment();
                    FragmentManager fm2 = getFragmentManager();
                    FragmentTransaction ft2 = fm2.beginTransaction();
                    ft2.replace(R.id.content_frame, lt1);
                    ft2.commit();

                }
            //}



        });

        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginFragment loginFragment2 = new LoginFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.content_frame,loginFragment2);
                ft.commit();
            }



        });



        return rootView;

    }
}
