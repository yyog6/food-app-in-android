package FoodFinder.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.deepu.foodfinder.R;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Forgot.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Forgot#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Forgot extends Fragment {

    EditText Email;
    Button btn_pass;
    Firebase ref;
    ProgressDialog progressBar;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_forgot, container, false);

        Firebase.setAndroidContext(getContext());
        ref = new Firebase("https://login-foodie-finder.firebaseio.com/");

        progressBar = new ProgressDialog(getContext());
        progressBar.setMessage("Loading...");

        Email = (EditText) rootView.findViewById(R.id.email_pass);
        btn_pass = (Button) rootView.findViewById(R.id.send_btn);

        btn_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.show();
                String email = Email.getText().toString();
                Firebase ref = new Firebase("https://login-foodie-finder.firebaseio.com/");
                ref.resetPassword(String.valueOf(Email), new Firebase.ResultHandler() {
                    @Override
                    public void onSuccess() {
                        // password reset email sent
                        Toast.makeText(getContext(), "Success", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(FirebaseError firebaseError) {
                        // error encountered
                    Toast.makeText(getContext(),"Incorrect email",Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });
        return rootView;
    }
}
