package Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by deepu on 22/05/16.
 */
public class RModel {

    private List<location> locationList;
    private List<user_rating> ratingList;

    private String image;
    private String name;
    private String url;

    public List<location> getLocationList() {
        return locationList;
    }

    public void setLocationList(List<location> locationList) {
        this.locationList = locationList;
    }

    public List<user_rating> getRatingList() {
        return ratingList;
    }

    public void setRatingList(List<user_rating> ratingList) {
        this.ratingList = ratingList;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    public static class location
    {
        public String address;
        public String locality;
        public   String city;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getLocality() {
            return locality;
        }

        public void setLocality(String locality) {
            this.locality = locality;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }
    }

    public static class user_rating{

        private String aggregate_rating;

        public String getAggregate_rating() {
            return aggregate_rating;
        }

        public void setAggregate_rating(String aggregate_rating) {
            this.aggregate_rating = aggregate_rating;
        }
    }
 }
