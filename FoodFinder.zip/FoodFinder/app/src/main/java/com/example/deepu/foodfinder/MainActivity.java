package com.example.deepu.foodfinder;

import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.firebase.client.core.Constants;

import FoodFinder.fragments.EventFragment;
import FoodFinder.fragments.ListFragment;
import FoodFinder.fragments.LoginFragment;
import FoodFinder.fragments.MainFragment;
import FoodFinder.fragments.RegisterFragment;
import FoodFinder.fragments.ShowList;


//https://www.youtube.com/watch?v=cUq_TxEC3Zo (list view refenrce)

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


  /*  EditText edt_name,edt_mail,edt_pass;
    Button btn_signup,btn_signin;
    Firebase ref;
    ProgressDialog PD;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);






        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);





        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        // Used <INSERTURL> as basis for constructing navigation view
        // What does navigation view do?
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        FragmentManager fm = getFragmentManager();
        fm.beginTransaction().replace(R.id.content_frame,new MainFragment()).commit();




/*
        Firebase.setAndroidContext(this);
        ref = new Firebase("https://login-foodie-finder.firebaseio.com/");

        PD = new ProgressDialog(this);
        PD.setMessage("Loading...");
        edt_name=(EditText)findViewById(R.id.edt_name);
        edt_pass=(EditText)findViewById(R.id.edt_pass);
        edt_mail=(EditText)findViewById(R.id.edt_mail);
        btn_signin=(Button)findViewById(R.id.btn_reg);
        btn_signup=(Button)findViewById(R.id.btn_link);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PD.show();
                String name = edt_name.getText().toString();
                String email = edt_mail.getText().toString();
                String pass = edt_pass.getText().toString();

                ref.child("users").child(name).child("name").setValue(name, new Firebase.CompletionListener() {

                    @Override
                    public void onComplete(FirebaseError error, Firebase firebase) {
                        if (error != null) {
                            Toast.makeText(getApplicationContext(), "Retry Again", Toast.LENGTH_LONG).show();
                        }
                        PD.dismiss();
                    }
                });

                ref.child("users").child(name).child("email").setValue(email, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError error, Firebase firebase) {
                        if (error != null) {
                            Toast.makeText(getApplicationContext(), "Retry Again", Toast.LENGTH_LONG).show();
                        }
                        PD.dismiss();
                    }
                });

                ref.child("users").child(name).child("pass").setValue(pass, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError error, Firebase firebase) {
                        if (error != null) {
                            Toast.makeText(getApplicationContext(), "Retry Again", Toast.LENGTH_LONG).show();
                        }
                        PD.dismiss();
                    }
                });

            }
        });



        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            }
        });

*/

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.


        FragmentManager fm = getFragmentManager();

        int id = item.getItemId();

        if (id == R.id.reg_lay) {
            fm.beginTransaction().replace(R.id.content_frame,new RegisterFragment()).commit();

        } else if (id == R.id.rest_list) {
            fm.beginTransaction().replace(R.id.content_frame, new ListFragment()).commit();

        } else if (id == R.id.nav_slideshow) {
            fm.beginTransaction().replace(R.id.content_frame, new EventFragment()).commit();

        } else if (id == R.id.nav_manage) {
            fm.beginTransaction().replace(R.id.content_frame,new ShowList()).commit();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
